#include <iostream>
#include <vector>
#include <string>

using namespace std;

struct Task
{
  string description;
  bool completed;
};


void
addTask (vector < Task > &tasks, const string & description)
{
  Task task;
  task.description = description;
  task.completed = false;
  tasks.push_back (task);
  cout << "Task added successfully!" << endl;
}


void
removeTask (vector < Task > &tasks, int index)
{
  if (index >= 0 && index < tasks.size ())
    {
      tasks.erase (tasks.begin () + index);
      cout << "Task removed successfully!" << endl;
    }
  else
    {
      cout << "Invalid task index!" << endl;
    }
}


void
completeTask (vector < Task > &tasks, int index)
{
  if (index >= 0 && index < tasks.size ())
    {
      tasks[index].completed = true;
      cout << "Task marked as completed!" << endl;
    }
  else
    {
      cout << "Invalid task index!" << endl;
    }
}

void
displayTasks (const vector < Task > &tasks)
{
  cout << "To-Do List:" << endl;
  for (size_t i = 0; i < tasks.size (); ++i)
    {
      const Task & task = tasks[i];
      cout << "[" << (task.completed ? "X" : " ") << "] " << i +
	1 << ". " << task.description << endl;
    }
}

int
main ()
{
  vector < Task > tasks;
  while (true)
    {
      cout << "Options:" << endl;
      cout << "1. Add a task" << endl;
      cout << "2. Remove a task" << endl;
      cout << "3. Complete a task" << endl;
      cout << "4. Display tasks" << endl;
      cout << "5. Quit" << endl;
      cout << "Enter your choice: ";

      int choice;
      cin >> choice;

      switch (choice)
	{
	case 1:
	  {
	    cout << "Enter task description: ";
	    string description;
	    cin.ignore ();
	    getline (cin, description);
	    addTask (tasks, description);
	    break;
	  }
	case 2:
	  {
	    int index;
	    cout << "Enter task index to remove: ";
	    cin >> index;
	    removeTask (tasks, index - 1);
	    break;
	  }
	case 3:
	  {
	    int index;
	    cout << "Enter task index to mark as completed: ";
	    cin >> index;
	    completeTask (tasks, index - 1);
	    break;
	  }
	case 4:
	  displayTasks (tasks);
	  break;
	case 5:
	  cout << "Goodbye!" << endl;
	  return 0;
	default:
	  cout << "Invalid choice. Please try again." << endl;
	  break;
	}
    }

  return 0;
}
